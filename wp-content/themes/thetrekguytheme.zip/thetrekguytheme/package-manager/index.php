<?php 

$page=isset($_GET["ttg-page"])?$_GET["ttg-page"]:'list.php';

require($page);

?>