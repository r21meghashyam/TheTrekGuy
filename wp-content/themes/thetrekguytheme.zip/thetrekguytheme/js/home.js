window.sr = ScrollReveal();
sr.reveal('.post', {
    duration: 1000,
    origin: 'bottom',
    viewFactor: 0.9,
    distance: "100px"

}, 1);
sr.reveal('.package', {
    duration: 700,
    origin: 'bottom',
    viewFactor: 0.9,
    distance: "100px"

}, 200);